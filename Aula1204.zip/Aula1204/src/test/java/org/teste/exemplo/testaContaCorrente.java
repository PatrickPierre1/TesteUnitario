package org.teste.exemplo;

import junit.framework.TestCase;

public class testaContaCorrente extends TestCase {

}