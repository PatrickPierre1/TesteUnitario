import org.junit.jupiter.api.Test;
import org.teste.exemplo.ContaCorrente;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class testaContaCorrente {
    @Test
    public void testa_deposito100() {
        ContaCorrente cc = new ContaCorrente("fulano");
        boolean result = cc.deposita(100);
        assertEquals(result, true);
    }
    @Test
    public void testa_depositoMenos100() {
        ContaCorrente cc = new ContaCorrente("fulano");
        boolean result = cc.deposita(-100);
        assertEquals(result, false);
    }

    @Test
    public void testa_deposito0() {
        ContaCorrente cc = new ContaCorrente("fulano");
        boolean result = cc.deposita(-100);
        assertEquals(result, false);
    }

    @Test
    public void testa_retirada0_100() {
        ContaCorrente cc = new ContaCorrente("fulano");
        cc.deposita(0);
        boolean result = cc.retirada(100);
        assertEquals(result, false);
    }
    @Test
    public void testa_retirada100_100() {
        ContaCorrente cc = new ContaCorrente("fulano");
        cc.deposita(100);
        boolean result = cc.retirada(100);
        assertEquals(result, true);
    }
    @Test
    public void testa_retirada100_150() {
        ContaCorrente cc = new ContaCorrente("fulano");
        cc.deposita(100);
        boolean result = cc.retirada(150);
        assertEquals(result, false);
    }
}
