package org.teste.exemplo;

public class ContaCorrente {
    String nome;
    int numeroConta;
    float saldo;
    private int numero = 0;

    public ContaCorrente(String nome) {
        this.nome = nome;
        this.numeroConta = numero++;
        this.saldo = 0;
    }


    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public int getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(int numeroConta) {
        this.numeroConta = numeroConta;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean deposita(float valor) {
        if(valor > 0 && valor <= saldo) {
            this.saldo += valor;
            return true;
        }else {
            return false;
        }
    }
    public boolean retirada(float valor) {
        if (valor <= saldo) {
            this.saldo -= valor;
            return true;
        }else {
            return false;
        }
    }
}
